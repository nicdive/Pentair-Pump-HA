"""Number platform for Pentair RS485 pump speed control."""

from __future__ import annotations

from homeassistant.components.number import NumberEntity, NumberMode
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN, MAX_GPM, MAX_RPM, MIN_GPM, MIN_RPM
from .coordinator import PentairPumpCoordinator
from .entity import PentairPumpEntity


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator: PentairPumpCoordinator = hass.data[DOMAIN][entry.entry_id][
        "coordinator"
    ]
    entities: list[NumberEntity] = []
    for pump in coordinator.hub.pumps:
        entities.append(PentairPumpRpmNumber(coordinator, pump.index))
        entities.append(PentairPumpGpmNumber(coordinator, pump.index))
    async_add_entities(entities)


class PentairPumpRpmNumber(PentairPumpEntity, NumberEntity):
    _attr_translation_key = "rpm"
    _attr_native_min_value = MIN_RPM
    _attr_native_max_value = MAX_RPM
    _attr_native_step = 50
    _attr_mode = NumberMode.AUTO
    _attr_native_unit_of_measurement = "rpm"

    @property
    def native_value(self) -> float | None:
        rpm = self.pump_data.get("rpm", 0)
        return float(rpm) if rpm else None

    async def async_set_native_value(self, value: float) -> None:
        await self.coordinator.hub.async_run_rpm(self.pump_index, int(value))
        await self.coordinator.async_request_refresh()


class PentairPumpGpmNumber(PentairPumpEntity, NumberEntity):
    _attr_translation_key = "gpm"
    _attr_native_min_value = MIN_GPM
    _attr_native_max_value = MAX_GPM
    _attr_native_step = 1
    _attr_mode = NumberMode.AUTO
    _attr_native_unit_of_measurement = "gpm"

    @property
    def native_value(self) -> float | None:
        gpm = self.pump_data.get("gpm", 0)
        return float(gpm) if gpm else None

    async def async_set_native_value(self, value: float) -> None:
        await self.coordinator.hub.async_run_gpm(self.pump_index, int(value))
        await self.coordinator.async_request_refresh()

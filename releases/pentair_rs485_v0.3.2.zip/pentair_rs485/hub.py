"""High-level pump control (standalone mode command sequences)."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass, field

from .const import DEFAULT_WATCHDOG_RECOVERY_DELAY
from .rs485.bus import RS485Bus
from .rs485.modes import decode_drivestate, decode_error, decode_mode
from .rs485.packets import (
    CommandProfile,
    PumpStatus,
    PumpType,
    pump_index_to_address,
    request_status,
    run_gpm,
    run_program,
    run_rpm,
    save_program,
    set_local_control,
    set_manual_mode,
    set_power,
    set_pump_mode,
    set_remote_control,
    set_speed1_mode,
    validate_gpm,
    validate_rpm,
)

_LOGGER = logging.getLogger(__name__)


@dataclass(slots=True)
class PumpConfig:
    index: int
    name: str
    pump_type: PumpType


@dataclass(slots=True)
class PentairHub:
    bus: RS485Bus
    app_address: int
    pumps: list[PumpConfig] = field(default_factory=list)
    _status: dict[int, PumpStatus] = field(default_factory=dict)
    _target_rpm: dict[int, int] = field(default_factory=dict)
    _target_gpm: dict[int, int] = field(default_factory=dict)
    _target_mode: dict[int, int] = field(default_factory=dict)
    _command_profile: dict[int, CommandProfile] = field(default_factory=dict)
    _should_run: dict[int, bool] = field(default_factory=dict)
    _display_active: dict[int, bool] = field(default_factory=dict)
    _hands_off: set[int] = field(default_factory=set)
    _recovery_in_progress: set[int] = field(default_factory=set)

    def __post_init__(self) -> None:
        for pump in self.pumps:
            if pump.pump_type == PumpType.VF:
                self._command_profile[pump.index] = CommandProfile.GPM
            else:
                self._command_profile[pump.index] = CommandProfile.RPM

    async def async_setup(self) -> None:
        await self.bus.async_open()

    async def async_shutdown(self) -> None:
        await self.bus.async_close()

    def get_status(self, index: int) -> PumpStatus | None:
        return self._status.get(index)

    def get_target_rpm(self, index: int) -> int | None:
        return self._target_rpm.get(index)

    def get_target_gpm(self, index: int) -> int | None:
        return self._target_gpm.get(index)

    def get_command_profile(self, index: int) -> CommandProfile:
        return self._command_profile.get(index, CommandProfile.RPM)

    def set_command_profile(self, index: int, profile: CommandProfile) -> None:
        self._command_profile[index] = profile
        _LOGGER.info("Pump %s command profile set to %s", index, profile.value)

    def set_target_rpm(self, index: int, rpm: int) -> None:
        self._target_rpm[index] = rpm

    def set_target_gpm(self, index: int, gpm: int) -> None:
        self._target_gpm[index] = gpm

    def get_target_mode(self, index: int) -> int | None:
        return self._target_mode.get(index)

    def set_target_mode(self, index: int, mode: int) -> None:
        self._target_mode[index] = mode
        _LOGGER.info("Pump %s target mode set to %s (%s)", index, mode, decode_mode(mode))

    def set_should_run(self, index: int, should_run: bool) -> None:
        self._should_run[index] = should_run

    def should_run(self, index: int) -> bool:
        return self._should_run.get(index, False)

    def is_display_active(self, index: int) -> bool:
        return self._display_active.get(index, False)

    def is_hands_off(self, index: int) -> bool:
        return index in self._hands_off

    def set_display_active(self, index: int, active: bool) -> None:
        self._display_active[index] = active
        _LOGGER.info("Pump %s display active set to %s", index, active)

    def is_recovery_in_progress(self, index: int) -> bool:
        return index in self._recovery_in_progress

    def status_dict(self, index: int, pump: PumpConfig) -> dict:
        status = self.get_status(index)
        if not status:
            return {
                "name": pump.name,
                "type": pump.pump_type.value,
                "command_profile": self.get_command_profile(index).value,
                "display_active": self.is_display_active(index),
                "hands_off": self.is_hands_off(index),
                "power": False,
                "rpm": 0,
                "gpm": 0,
                "watts": 0,
                "err": 0,
                "err_label": "ok",
                "mode": 0,
                "mode_label": "filter",
                "target_mode": None,
                "target_mode_label": None,
                "drivestate": 0,
                "drivestate_label": "fault",
                "ppc": 0,
                "timer": 0,
                "hour": 0,
                "minute": 0,
            }
        return {
            "name": pump.name,
            "type": pump.pump_type.value,
            "command_profile": self.get_command_profile(index).value,
            "display_active": self.is_display_active(index),
            "hands_off": self.is_hands_off(index),
            "power": status.is_on,
            "rpm": status.rpm,
            "gpm": status.gpm,
            "watts": status.watts,
            "err": status.err,
            "err_label": decode_error(status.err),
            "mode": status.mode,
            "mode_label": decode_mode(status.mode),
            "target_mode": self.get_target_mode(index),
            "target_mode_label": (
                decode_mode(self.get_target_mode(index))
                if self.get_target_mode(index) is not None
                else None
            ),
            "drivestate": status.drivestate,
            "drivestate_label": decode_drivestate(status.drivestate),
            "ppc": status.ppc,
            "timer": status.timer,
            "hour": status.hour,
            "minute": status.minute,
        }

    def _address(self, index: int) -> int:
        return pump_index_to_address(index)

    def _wrap_remote_sequence(self, index: int, middle: list[bytes]) -> list[bytes]:
        """Remote prefix; release to local panel when display-active mode is on."""
        address = self._address(index)
        packets = [set_remote_control(self.app_address, address)]
        packets.extend(middle)
        if self.is_display_active(index):
            packets.append(set_local_control(self.app_address, address))
        return packets

    def _resume_remote_control(self, index: int) -> None:
        self._hands_off.discard(index)

    async def _run_command(self, index: int, middle: list[bytes]) -> PumpStatus | None:
        self._resume_remote_control(index)
        return await self._run_sequence(
            index, self._wrap_remote_sequence(index, middle)
        )

    async def _run_sequence(self, index: int, packets: list[bytes]) -> PumpStatus | None:
        responses = await self.bus.async_send_sequence(packets)
        return self._store_responses(responses, index)

    async def async_set_pump_mode(self, index: int, mode: int) -> PumpStatus | None:
        self.set_target_mode(index, mode)
        address = self._address(index)
        _LOGGER.info("Set pump %s mode %s (address %s)", index, mode, address)
        return await self._run_command(
            index,
            [
                set_pump_mode(self.app_address, address, mode),
                request_status(self.app_address, address),
            ],
        )

    async def async_send_manual_mode(self, index: int) -> PumpStatus | None:
        """Wiki action 5 mode 1 = Manual."""
        self.set_target_mode(index, 1)
        address = self._address(index)
        return await self._run_command(
            index,
            [
                set_manual_mode(self.app_address, address),
                request_status(self.app_address, address),
            ],
        )

    async def async_send_speed1_mode(self, index: int) -> PumpStatus | None:
        """Wiki action 5 mode 2 = Speed 1 (post power-cut recovery on some pumps)."""
        self.set_target_mode(index, 2)
        address = self._address(index)
        return await self._run_command(
            index,
            [
                set_speed1_mode(self.app_address, address),
                request_status(self.app_address, address),
            ],
        )

    async def async_set_display_active(self, index: int, active: bool) -> PumpStatus | None:
        """Toggle IntelliComm-style display mode (panel stays active between commands)."""
        self.set_display_active(index, active)
        address = self._address(index)
        if active:
            self._hands_off.discard(index)
            return await self._run_sequence(
                index, [set_local_control(self.app_address, address)]
            )
        return await self._run_sequence(
            index,
            [
                set_remote_control(self.app_address, address),
                request_status(self.app_address, address),
            ],
        )

    async def async_release_to_pump(self, index: int) -> PumpStatus | None:
        """Return physical panel control; HA stops grabbing remote until next command."""
        self._hands_off.add(index)
        self.set_display_active(index, True)
        address = self._address(index)
        _LOGGER.info("Pump %s released to local panel control", index)
        return await self._run_sequence(
            index, [set_local_control(self.app_address, address)]
        )

    async def async_send_local_control(self, index: int) -> PumpStatus | None:
        return await self.async_release_to_pump(index)

    async def async_recover_setpoint(
        self, index: int, delay: float = DEFAULT_WATCHDOG_RECOVERY_DELAY
    ) -> None:
        if index in self._recovery_in_progress:
            return
        profile = self.get_command_profile(index)
        self._recovery_in_progress.add(index)
        try:
            status = self.get_status(index)
            target_mode = self.get_target_mode(index)
            mode_mismatch = (
                target_mode is not None
                and status is not None
                and status.mode != target_mode
            )

            if mode_mismatch:
                _LOGGER.warning(
                    "Watchdog pump %s: restoring mode %s (measured %s)",
                    index,
                    decode_mode(target_mode),
                    decode_mode(status.mode),
                )
                await self.async_set_pump_mode(index, target_mode)
                await asyncio.sleep(delay)

            if profile == CommandProfile.RPM:
                target = self.get_target_rpm(index)
                if target is None:
                    return
                measured = status.rpm if status else 0
                if abs(measured - target) <= 100:
                    return
                if target_mode is None and not mode_mismatch:
                    _LOGGER.warning(
                        "Watchdog pump %s: no target mode, using manual before %s RPM",
                        index,
                        target,
                    )
                    await self.async_set_pump_mode(index, 1)
                    await asyncio.sleep(delay)
                _LOGGER.warning(
                    "Watchdog pump %s: restoring %s RPM in %ss",
                    index,
                    target,
                    delay,
                )
                await self.async_run_rpm(index, target)
            else:
                target = self.get_target_gpm(index)
                if target is None:
                    return
                measured = status.gpm if status else 0
                if abs(measured - target) <= 5:
                    return
                if target_mode is None and not mode_mismatch:
                    _LOGGER.warning(
                        "Watchdog pump %s: no target mode, using manual before %s GPM",
                        index,
                        target,
                    )
                    await self.async_set_pump_mode(index, 1)
                    await asyncio.sleep(delay)
                _LOGGER.warning(
                    "Watchdog pump %s: restoring %s GPM in %ss",
                    index,
                    target,
                    delay,
                )
                await self.async_run_gpm(index, target)
        finally:
            self._recovery_in_progress.discard(index)

    async def async_request_status(self, index: int) -> PumpStatus | None:
        if self.is_hands_off(index):
            return self.get_status(index)
        address = self._address(index)
        status = await self._run_sequence(
            index,
            self._wrap_remote_sequence(
                index, [request_status(self.app_address, address)]
            ),
        )
        if status is None:
            _LOGGER.warning("No status for pump %s", index)
        return status

    async def async_set_power(self, index: int, power: bool) -> PumpStatus | None:
        self.set_should_run(index, power)
        address = self._address(index)
        return await self._run_command(
            index,
            [
                set_power(self.app_address, address, power),
                request_status(self.app_address, address),
            ],
        )

    async def async_run_rpm(self, index: int, rpm: int) -> PumpStatus | None:
        if not validate_rpm(rpm):
            raise ValueError(f"RPM {rpm} out of range")
        self.set_target_rpm(index, rpm)
        self.set_should_run(index, True)
        address = self._address(index)
        return await self._run_command(
            index,
            [
                set_power(self.app_address, address, True),
                run_rpm(self.app_address, address, rpm),
                request_status(self.app_address, address),
            ],
        )

    async def async_run_gpm(self, index: int, gpm: int) -> PumpStatus | None:
        if not validate_gpm(gpm):
            raise ValueError(f"GPM {gpm} out of range")
        self.set_target_gpm(index, gpm)
        self.set_should_run(index, True)
        address = self._address(index)
        return await self._run_command(
            index,
            [
                set_power(self.app_address, address, True),
                run_gpm(self.app_address, address, gpm),
                request_status(self.app_address, address),
            ],
        )

    async def async_run_program(self, index: int, program: int) -> PumpStatus | None:
        address = self._address(index)
        middle: list[bytes] = [run_program(self.app_address, address, program)]
        if program != 0:
            self.set_should_run(index, True)
            status = self.get_status(index)
            if not status or not status.is_on:
                middle.insert(0, set_power(self.app_address, address, True))
        middle.append(request_status(self.app_address, address))
        return await self._run_command(index, middle)

    async def async_save_program(
        self, index: int, program: int, speed: int
    ) -> PumpStatus | None:
        if not 1 <= program <= 4:
            raise ValueError(f"Invalid program {program}")
        profile = self.get_command_profile(index)
        if profile == CommandProfile.GPM and not validate_gpm(speed):
            raise ValueError(f"GPM {speed} out of range")
        if profile == CommandProfile.RPM and not validate_rpm(speed):
            raise ValueError(f"RPM {speed} out of range")
        address = self._address(index)
        return await self._run_command(
            index,
            [
                save_program(self.app_address, address, program, speed),
                request_status(self.app_address, address),
            ],
        )

    async def async_poll_all(self) -> None:
        for pump in self.pumps:
            if not self.is_hands_off(pump.index):
                await self.async_request_status(pump.index)

    def _store_responses(
        self, responses: list[PumpStatus], index: int
    ) -> PumpStatus | None:
        for status in responses:
            self._status[status.index] = status
        return self._status.get(index)

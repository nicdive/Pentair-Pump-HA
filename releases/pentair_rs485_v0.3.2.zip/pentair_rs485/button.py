"""Button platform for Pentair RS485 pumps."""

from __future__ import annotations

from homeassistant.components.button import ButtonEntity
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback

from .const import DOMAIN
from .coordinator import PentairPumpCoordinator
from .entity import PentairPumpEntity


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator: PentairPumpCoordinator = hass.data[DOMAIN][entry.entry_id][
        "coordinator"
    ]
    entities: list[ButtonEntity] = []
    for pump in coordinator.hub.pumps:
        entities.extend(
            [
                PentairManualModeButton(coordinator, pump.index),
                PentairSpeed1ModeButton(coordinator, pump.index),
                PentairFilterModeButton(coordinator, pump.index),
                PentairLocalControlButton(coordinator, pump.index),
                PentairRunProgramButton(coordinator, pump.index, 1),
                PentairRunProgramButton(coordinator, pump.index, 2),
                PentairRunProgramButton(coordinator, pump.index, 3),
                PentairRunProgramButton(coordinator, pump.index, 4),
                PentairStopProgramButton(coordinator, pump.index),
            ]
        )
    async_add_entities(entities)


class PentairManualModeButton(PentairPumpEntity, ButtonEntity):
    _attr_translation_key = "manual_mode"
    _attr_icon = "mdi:hand-back-right"

    async def async_press(self) -> None:
        await self.coordinator.hub.async_send_manual_mode(self.pump_index)
        await self.coordinator.async_request_refresh()


class PentairSpeed1ModeButton(PentairPumpEntity, ButtonEntity):
    _attr_translation_key = "speed1_mode"
    _attr_icon = "mdi:speedometer"

    async def async_press(self) -> None:
        await self.coordinator.hub.async_send_speed1_mode(self.pump_index)
        await self.coordinator.async_request_refresh()


class PentairFilterModeButton(PentairPumpEntity, ButtonEntity):
    _attr_translation_key = "filter_mode"
    _attr_icon = "mdi:filter"

    async def async_press(self) -> None:
        await self.coordinator.hub.async_set_pump_mode(self.pump_index, 0)
        await self.coordinator.async_request_refresh()


class PentairLocalControlButton(PentairPumpEntity, ButtonEntity):
    _attr_translation_key = "release_remote"
    _attr_icon = "mdi:gesture-tap-button"

    async def async_press(self) -> None:
        await self.coordinator.hub.async_release_to_pump(self.pump_index)
        await self.coordinator.async_request_refresh()


class PentairRunProgramButton(PentairPumpEntity, ButtonEntity):
    _attr_has_entity_name = True

    def __init__(
        self,
        coordinator: PentairPumpCoordinator,
        pump_index: int,
        program: int,
    ) -> None:
        super().__init__(coordinator, pump_index)
        self._program = program
        self._attr_translation_key = f"run_program_{program}"
        self._attr_unique_id = f"{DOMAIN}_{pump_index}_run_program_{program}"

    async def async_press(self) -> None:
        await self.coordinator.hub.async_run_program(self.pump_index, self._program)
        await self.coordinator.async_request_refresh()


class PentairStopProgramButton(PentairPumpEntity, ButtonEntity):
    _attr_translation_key = "stop_program"
    _attr_icon = "mdi:stop"

    async def async_press(self) -> None:
        await self.coordinator.hub.async_run_program(self.pump_index, 0)
        await self.coordinator.async_request_refresh()
